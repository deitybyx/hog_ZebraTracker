This file explains the usage of included binary and MATLAB code. Detailed information of each script is listed inside each script.

The code is applied to MATLAB015b and above. The file Trace.m is the entry to the GUI interface. The format of input video is AVI with high expansibility.