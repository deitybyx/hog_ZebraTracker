function fragment = Z2fragment(handles)
    seqName = handles.seqName;
    numOfFishes = handles.numOfFishes;
    set(handles.txtInfo,'String',['Z2fragment...']);
    load([seqName,'/',seqName,'_Z.mat'],'Z');
    
    fishIndex = zeros(numOfFishes,length(Z));
    nCurrentLabel = length(Z(1).centerCoor);
    fishIndex(1:nCurrentLabel,1) = 1:nCurrentLabel;
    INDEX = 1:handles.numOfFishes;

    %% assign the fishIndex
    for frm = 2:length(Z)
        if frm == 1
        end
        lastCenterCoor = Z(frm-1).centerCoor;
        currentCenterCoor = Z(frm).centerCoor;
        if length(lastCenterCoor) == length(currentCenterCoor)      % number of targets match
            dis = zeros(length(lastCenterCoor));
            for kk = 1:length(lastCenterCoor)
                dis(kk,:) = sqrt((currentCenterCoor(1,:) - lastCenterCoor(1,kk)).^2 + (currentCenterCoor(2,:) - lastCenterCoor(2,kk)).^2);
            end
            [dis_sorted,dis_idx] = sort(dis,2);
            if length(unique(dis_idx(:,1))) == length(lastCenterCoor)
                dis_unsure_idx = dis_sorted(:,2) - dis_sorted(:,1) < 1;
                if sum(dis_unsure_idx) > 1
                    fishIndex(dis_idx(~dis_unsure_idx),frm) = fishIndex(~dis_unsure_idx,frm-1);
                    fishIndex(dis_unsure_idx,frm) = (nCurrentLabel+1):(nCurrentLabel+sum(dis_unsure_idx));
                    nCurrentLabel = nCurrentLabel + sum(dis_unsure_idx);
                else
                    fishIndex(dis_idx(:,1),frm) = fishIndex(1:size(dis_idx,1),frm-1);   
                end
            else
                [~,ele_index] = OneTimeElement(dis_idx(:,1));
                fishIndex(dis_idx(ele_index,1),frm) = fishIndex(ele_index,frm-1);
                index_unsure = INDEX(1:length(ele_index));
                index_unsure(dis_idx(ele_index,1)) = [];
                fishIndex(index_unsure,frm) = (nCurrentLabel+1):(nCurrentLabel+length(index_unsure));
                nCurrentLabel = nCurrentLabel + length(index_unsure);
            end
        elseif length(lastCenterCoor) < length(currentCenterCoor)   % number of targets increase or increase
            dis = zeros(length(lastCenterCoor),length(currentCenterCoor));
            for kk = 1:length(lastCenterCoor)
                dis(kk,:) = sqrt((currentCenterCoor(1,:)-lastCenterCoor(1,kk)).^2 + (currentCenterCoor(2,:) - lastCenterCoor(2,kk)).^2);
            end
            
            [sorted,sorted_idx] = sort(dis',2);
            [~,index] = OneTimeElement(sorted_idx(:,1));
            unsure_index = sorted_idx(sorted(:,2) - sorted(:,1) < 30,2);
            unsure_index = find(ismember(sorted_idx(:,1),unsure_index));
            unsure_index = unique([unsure_index',find(~index)']);
            fishIndex(index,frm) = fishIndex(sorted_idx(index,1),frm-1);
            
            fishIndex(unsure_index,frm) = (nCurrentLabel + 1)  : nCurrentLabel + sum(unsure_index>0);
            nCurrentLabel = nCurrentLabel + sum(unsure_index>0);
            

        else % length(lastCenterCoor) > length(currentCenterCoor)
            dis = zeros(length(lastCenterCoor),length(currentCenterCoor));
            for kk = 1:length(lastCenterCoor)
                dis(kk,:) = sqrt((currentCenterCoor(1,:)-lastCenterCoor(1,kk)).^2 + (currentCenterCoor(2,:) - lastCenterCoor(2,kk)).^2);
            end
            
%             [predict_left,predict_right] = KM(dis);
            [sorted,sorted_idx] = sort(dis,2);
             [~,indexOTE] = OneTimeElement(sorted_idx(:,1));            
            fishIndex(sorted_idx(indexOTE,1),frm) = fishIndex(indexOTE,frm-1);
            
            unsure_index = sorted_idx(sorted(:,2)-sorted(:,1)<30,2);
            unsure_index = unique([unsure_index',sorted_idx(~indexOTE,1)']);
            
            fishIndex(unsure_index,frm) = (nCurrentLabel + 1)  : (nCurrentLabel + sum(unsure_index>0));
            nCurrentLabel = nCurrentLabel + sum(unsure_index>0);


        end
    end
	%% convert into fragments with field 't_start','t_end','centerCoor','imageCroped'
    set(handles.txtInfo,'String',['Z2fragment - Generate Original fragment']);pause(0.01);
    fragment = struct('t_start',[],'t_end',[],'centerCoor',zeros(2,1),'imageCroped',cell(0));
    for frm = 1:length(Z)    
       for no = 1:length(Z(frm).centerCoor)
            fi = fishIndex(no,frm);
            if fi ~= 0
                fragment(fi).t_end = frm;
                if isempty(fragment(fi).t_start)
                    fragment(fi).t_start = frm;
                end
                fragment(fi).centerCoor(:,end+1) = Z(frm).centerCoor(:,no);
                fragment(fi).imageCroped{:,end+1} = Z(frm).imageCroped{1,no};
            end
        end
    end
    
    %% contact coordinate that contains more than one fish to the end of the fragments
    set(handles.txtInfo,'String',['Z2fragment - First combination']);pause(0.01);
    t_start = [fragment.t_start];
    [count,element] = hist(t_start,unique(t_start));
    indexToDelete = zeros(1,length(fragment));
    uniEle = element(count == 1);
    for ele =uniEle
        indx = find([fragment.t_end] == ele -1);
        eleIndex = find(t_start == ele);
        %         for idx = indx
        for iidx = 1:length(indx)
            idx = indx(iidx);
            %             if length(fragment(eleIndex).centerCoor) < 10
            fragment(idx).centerCoor = [fragment(idx).centerCoor,zeros(size(fragment(eleIndex).centerCoor))-2];
            %             else
            %                 fragment(idx).centerCoor = [fragment(idx).centerCoor,fragment(eleIndex).centerCoor];
            %                 fragment(idx).imageCroped = [fragment(idx).imageCroped,fragment(eleIndex).imageCroped];
            %             end
            fragment(idx).t_end = fragment(eleIndex).t_end;
        end
        indexToDelete(eleIndex) = 1;
        
    end
    fragment(logical(indexToDelete)) = [];
    
    %% another situation - there is only one unique end, which resembles two fishes seperate at this point
    set(handles.txtInfo,'String',['Z2fragment - Second combination']);pause(0.01);
    t_end = [fragment.t_end];
    [count,element] = hist(t_end,unique(t_end));
    indexToDelete = zeros(1,length(fragment));
    uniEle = element(count == 1);
    
    for ele =uniEle
        indx = find([fragment.t_start] == ele + 1);
        eleIndex = find(t_end == ele);
        if length(indx) == 1
            for idx = indx
                fragment(idx).t_start = fragment(eleIndex).t_start;
                %             if length(fragment(eleIndex).centerCoor) < 10
                fragment(idx).centerCoor = [zeros(size(fragment(eleIndex).centerCoor))-2,fragment(idx).centerCoor];
                %             else
                %                 fragment(idx).centerCoor = [fragment(eleIndex).centerCoor,fragment(idx).centerCoor];
                %                 fragment(idx).imageCroped = [fragment(eleIndex).imageCroped,fragment(idx).imageCroped];
                %             end
            end
            indexToDelete(eleIndex) = 1;
        end
    end
    fragment(logical(indexToDelete)) = [];
end