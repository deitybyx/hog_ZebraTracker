clf;

 
plot(idl(frm).centerCoor(:,1),idl(frm).centerCoor(:,2),'*r');
hold on
text(idl(frm).centerCoor(:,1),idl(frm).centerCoor(:,2),['1' '2' '3' '4']');
% text(idl(frm).centerCoor(:,1),idl(frm).centerCoor(:,2),['1' '2' '3' '4' '5']');
plot(idl(frm+1).centerCoor(:,1),idl(frm+1).centerCoor(:,2),'*b');
text(idl(frm+1).centerCoor(:,1),idl(frm+1).centerCoor(:,2),['1' '2' '3' '4']');
% text(idl(frm+1).centerCoor(:,1),idl(frm+1).centerCoor(:,2),['1' '2' '3' '4' '5']');

    if sum(row_conflict)>0 || sum(col_conflict)>0
        if length(predict_left) < length(predict_right)
            plot([idl(frm).centerCoor(predict_right(:),1)';idl(frm+1).centerCoor(1:length(predict_right),1)'],...
                [idl(frm).centerCoor(predict_right(:),2)';idl(frm+1).centerCoor(1:length(predict_right),2)'],'-g');
        elseif length(predict_left) > length(predict_right)

            plot([idl(frm).centerCoor(1:length(predict_left),1)';idl(frm+1).centerCoor(predict_left(:),1)'],...
                [idl(frm).centerCoor(1:length(predict_left),2)';idl(frm+1).centerCoor(predict_left(:),2)'],'-g');
        else % length(predict_left) == length(predict_right)
            plot([idl(frm).centerCoor(1:length(predict_left),1)';idl(frm+1).centerCoor(predict_left(:),1)'],...
                [idl(frm).centerCoor(1:length(predict_left),2)';idl(frm+1).centerCoor(predict_left(:),2)'],'-g');
        end
    else
        plot([idl(frm).centerCoor(:,1)';idl(frm+1).centerCoor(predict(:),1)'],...
            [idl(frm).centerCoor(:,2)';idl(frm+1).centerCoor(predict(:),2)'],'-g');
    end
    xlim([0,1400]);
    ylim([0,1000]);
    if ~exist('pic','dir')
        !mkdir pic
    end

    saveas(gcf,['pic\' num2str(NCOUNT) '.jpg']);
NCOUNT = NCOUNT + 1;