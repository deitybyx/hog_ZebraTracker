function [element,index] = OneTimeElement(arr)
    [count,element] = hist(arr,unique(arr));
    element(count~=1) = [];
    index = false(size(arr));
    for i = 1:length(element)
        index(arr == element(i)) = 1;
    end
end