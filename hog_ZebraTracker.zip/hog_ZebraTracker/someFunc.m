load 12345ѹ��75/12345ѹ��75_fragment.mat;

aa = 1:size(fishIndex,2);
for idx = 1:size(fragment,1)
        frm = fragment{idx}.t_end;
        disp(['In:' num2str(idx)]);
        if idx == 296
        end
        if frm < size(fishIndex,2)
            predict = matchLabel(aa(fishIndex(:,frm) == fragment{idx}.id),frm); % the position of this fish at next frame

            if predict > 0
                while 1
                    if all(matchLabel(:,frm + 1) <= 0)
                        if sum(matchLabel(:,frm+1) == -predict) == 1
                            predict = abs(aa(matchLabel(:,frm+1) == -predict));
                        else
                            fragment{idx}.t_end = fragment{idx}.t_end + 1;
                            fragment{idx}.length = fragment{idx}.length + 1;
                            fragment{idx}.centerCoor = [fragment{idx}.centerCoor;idl(frm + 1).centerCoor(predict,:)];
                            fragment{idx}.Long2Short = [fragment{idx}.Long2Short;idl(frm + 1).Long2Short(predict,:)];
                            break;
                        end
                    else
                        predict = matchLabel(predict,frm + 1);
                    end
                    fragment{idx}.t_end = fragment{idx}.t_end + 1;
                    fragment{idx}.length = fragment{idx}.length + 1;
                    fragment{idx}.centerCoor = [fragment{idx}.centerCoor;idl(frm + 1).centerCoor(predict,:)];
                    fragment{idx}.Long2Short = [fragment{idx}.Long2Short;idl(frm + 1).Long2Short(predict,:)];
                    frm = frm + 1;
                end
            end
        end
    end