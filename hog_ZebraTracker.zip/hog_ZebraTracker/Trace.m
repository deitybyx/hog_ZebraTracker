%% main function
function varargout = Trace(varargin)

    % Begin initialization code - DO NOT EDIT
    gui_Singleton = 1;
    gui_State = struct('gui_Name',       mfilename, ...
                       'gui_Singleton',  gui_Singleton, ...                                                           
                       'gui_OpeningFcn', @Trace_OpeningFcn, ...
                       'gui_OutputFcn',  @Trace_OutputFcn, ...                  
                       'gui_LayoutFcn',  [] , ...
                       'gui_Callback',   []);
    if nargin && ischar(varargin{1})
        gui_State.gui_Callback = str2func(varargin{1});
    end

    if nargout                        
        [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
    else
        gui_mainfcn(gui_State, varargin{:});
    end
    % End initialization code - DO NOT EDIT
end
                                                      
function Trace_OpeningFcn(hObject, ~, handles, varargin)
    addpath('function');
    addpath('function\libsvm\matlab');
    handles.output = hObject;                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                              
    clc;
    %% ��������
    global color4fish;                                                                                                                                                                                                                                                                                                                                                                                                                                       
    global coordinate;
    color4fish = [];
    coordinate = [];
    global gStateControl;
    gStateControl.bPause = 0;
    gStateControl.bShowTrace = 0;
    gStateControl.button = 0;                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                               
    gStateControl.currentMousePosition = [];
    gStateControl.imageType = 1;
    gStateControl.correctionMode = 0;
    gStateControl.correctionMatch = [];
    gStateControl.correctionIndex = 1;
    
    global trackletInfo;
    trackletInfo.ZITL = [];
    trackletInfo.color4Fish = [];
    trackletInfo.coordinate = [];
    
    
    gStateControl.Online_Offline_Model = 1;
    set(handles.rbOfflineModel,'Value',1);
    handles.grayThreshold = 50;
    handles.areaThreshold = 500;
    handles.currentFrame = 1;
    handles.totalFrames = 0;
    handles.imageHandle = 0;
    handles.background = [];
    
    set(handles.edtGrayThreshold,'String',handles.grayThreshold);
    set(handles.edtAreaThreshold,'String',handles.areaThreshold);
    set(handles.sldCurrentFrame,'sliderstep',[0.01,0.01]);
    set(handles.btnBinaryImage,'enable','off');
    set(handles.btnSaveParams,'enable','off');
    set(handles.btnTrace,'enable','off');
    set(handles.btnShowTrace,'enable','off');
    set(handles.btnManuCorrection,'enable','off');
    set(handles.btnConfirm,'enable','off');
    set(handles.btnCancel,'enable','off');
    set(handles.btnPlay,'enable','off');
    set(handles.btnPause,'enable','off');
    set(handles.btnNext,'enable','off');
    set(handles.btnPrevious,'enable','off');
    set(handles.btnOriginalImage,'enable','off');
    set(handles.btnGetBackground,'enable','off');
    
    set(handles.btnCorrectionPrevious,'enable','off');
    set(handles.btnCorrectionNext,'enable','off');
    set(handles.ppmCurrentCorrectionId,'enable','off');
    set(handles.txtCorrectionGoTo,'enable','off');
    set(handles.btnAccept,'enable','off');
    
    % edit 
    set(handles.edtCurrentFrame,'enable','off');
    set(handles.edtGrayThreshold,'enable','off');
    set(handles.edtAreaThreshold,'enable','off');
    set(handles.sldCurrentFrame,'enable','off');
    
    axes(handles.axesImage);
%     annotation('textbox',[.2 .5 .3 .3],'String','Please open a video to continue all the operations','FitBoxToText','on','color','r','LineColor','r');
    text(.3,.5,'Please open a video to continue all the operations','FontSize',14,'color','r');
    grid off;
    
    guidata(hObject, handles);
end

function varargout = Trace_OutputFcn(~, ~, handles) 
    varargout{1} = handles.output;
end
%% Preview an image
function preview(handles,hObject)
    axes(handles.axesImage);
    global gStateControl;
    hold off;
    if ~isempty(handles.video)
        image = read(handles.video,handles.currentFrame);
        xlimValue = get(gca,'XLim');
        ylimValue = get(gca,'YLim');
        if gStateControl.imageType == 1
            handles.imageHandle = imshow(image);
            set(handles.imageHandle,'ButtonDownFcn',{@keydown_fcn,handles,hObject});
        elseif gStateControl.imageType == 2     % binary image
            image = rgb2gray(image);
            meanValue = mean(mean(image));
            image(image>meanValue +10) = meanValue + 10;
            imgBinary = abs(double(image) - double(handles.background))...
                > handles.grayThreshold;
            some = regionprops(imgBinary,'area','Orientation','BoundingBox','Centroid');
            toFill = some([some.Area] < [handles.areaThreshold],:);
            for k = 1:size(toFill,1)
                row = round(toFill(k).BoundingBox(2));
                col = round(toFill(k).BoundingBox(1));
                for i = row:row + toFill(k).BoundingBox(4)
                    for j = col : col + toFill(k).BoundingBox(3)
                        imgBinary(i,j) = 0;
                    end
                end
            end
            [~,numOfFishes] = bwlabel(imgBinary);
%             handles.numOfFishes = numOfFishes;
            handles.imageHandle = imshow(imgBinary);
            set(handles.imageHandle,'ButtonDownFcn',{@keydown_fcn,handles,hObject});
        end
        xlim(xlimValue);
        ylim(ylimValue);

        if gStateControl.bShowTrace == 1
            DisplayPossipleMatch(handles,hObject);
        end
        set(handles.sldCurrentFrame,'value',handles.currentFrame);
        set(handles.txtCurrentFrame,'String',strcat(num2str(handles.currentFrame), ' / ',num2str(handles.totalFrames)));
        set(handles.edtCurrentFrame,'String',num2str(handles.currentFrame));
        guidata(hObject,handles);
    end
end
%% Open Video File && Get Bakcground
function btnOpen_Callback(hObject, ~, handles)
    global gStateControl;
    global color4fish;
    global coordinate;
    [filename,filepath] = uigetfile('*.avi');
    if filename ~=0
        handles.currentFrame = 1;
        seqName = filename(1:length(filename)-4);
        if ~exist(seqName,'dir')
            dos(['mkdir ',seqName]);
        end
        %% Get params & preview picture
        video = VideoReader([filepath '\' filename]);
        handles.filepath = filepath;
        handles.filename = filename;
        handles.seqName = seqName;
        handles.video = video;
        gStateControl.imageType = 1;
        gStateControl.id4fish2show = [];
        handles.videoWidth = video.Width;
        handles.videoHeight = video.Height;
        xlim([0,video.Width]);
        ylim([0,video.Height]);
        handles.totalFrames = video.NumberOfFrames;
        handles.background = [];
        
        set(handles.txtCurrentFrame,'String',strcat(num2str(handles.currentFrame), ' / ',num2str(handles.totalFrames)));
        set(handles.sldCurrentFrame,'value',handles.currentFrame);
        set(handles.sldCurrentFrame,'max',handles.totalFrames);
        set(handles.sldCurrentFrame,'sliderstep',[1./handles.totalFrames,10./handles.totalFrames]);
        fileParams = [handles.filepath,'\',handles.seqName,'\',handles.seqName,'_Params.mat'];
        set(handles.lstID,'String',[]);
        if exist(fileParams,'file')
            load(fileParams);
            handles.grayThreshold = grayThreshold;
            handles.areaThreshold = areaThreshold;
            handles.numOfFishes = numOfFishes;
            
            set(handles.lstID,'String',1:numOfFishes);
            set(handles.edtGrayThreshold,'String',handles.grayThreshold);
            set(handles.edtAreaThreshold,'String',handles.areaThreshold);
            handles.numOfFishes = numOfFishes;
        end
        color4fish = [];
        coordinate = [];
        preview(handles,hObject);
        
        
        %% disable buttons
        set(handles.btnGetBackground,'enable','on');
        set(handles.edtGrayThreshold,'enable','off');
        set(handles.edtAreaThreshold,'enable','off');
        set(handles.edtCurrentFrame,'enable','on');
        set(handles.sldCurrentFrame,'enable','on');
        set(handles.btnPrevious,'enable','on');
        set(handles.btnNext,'enable','on');
        set(handles.btnOriginalImage,'enable','off');
        set(handles.btnBinaryImage,'enable','off');
        set(handles.btnSaveParams,'enable','off');
        set(handles.btnTrace,'enable','off');
        set(handles.btnShowTrace,'enable','off');
        set(handles.btnPlay,'enable','off');
        set(handles.btnPause,'enable','off');
        
        set(handles.btnManuCorrection,'enable','off');
        set(handles.btnConfirm,'enable','off');
        set(handles.btnCancel,'enable','off');
        
        set(handles.btnCorrectionPrevious,'enable','off');
        set(handles.btnCorrectionNext,'enable','off');
        set(handles.ppmCurrentCorrectionId,'enable','off');
        set(handles.txtCorrectionGoTo,'enable','off');
        set(handles.btnAccept,'enable','off');
        
        
        gStateControl.id4fish2show = [];
        gStateControl.bShowTrace = 0;
        set(handles.txtInfo,'String','Quit ManuCorrection Mode');
        gStateControl.bShowTrace = 0;
        set(handles.btnShowTrace,'String','Display trace');
        
        set(handles.txtInfo,'String','Open video file successfully.');
    else
        set(handles.txtInfo,'String','Open video file unsuccessfully.');
    end
end
        

function btnGetBackground_Callback(hObject, eventdata, handles)
    if isfield(handles,'filepath')
        filepath = [handles.filepath,'/',handles.seqName,'/',handles.seqName,'_background.mat'];
        if isempty(handles.background)
            if ~exist(filepath , 'file')
                background = GetBackground([handles.filepath,'/',handles.filename],1);
                meanValue = mean(mean(background));
                background(background > meanValue + 10) = meanValue + 10;
                save(filepath,'background');
            else
                load(filepath,'background');
            end
            handles.background = double(background);
        end
        axes(handles.axesImage);
        handles.imageHandle = imshow(uint8(handles.background));
        set(handles.imageHandle,'ButtonDownFcn',{@keydown_fcn,handles,hObject});
        guidata(hObject,handles);
        
        set(handles.btnOriginalImage,'enable','on');
        set(handles.btnBinaryImage,'enable','on');
        set(handles.edtGrayThreshold,'enable','on');
        set(handles.edtAreaThreshold,'enable','on');
        set(handles.btnTrace,'enable','on');
        set(handles.txtInfo,'String','Get background successfully.');
        disp('Get background successfully.');
    else
        set(handles.txtInfo,'String','Failed! Please Open video file first.');
        disp('Please Open video file first.');
    end
end
%% Params Setting
function edtAreaThreshold_Callback(hObject, eventdata, handles)
    handles.areaThreshold = str2double(get(hObject,'String'));
    guidata(hObject,handles);
    preview(handles,hObject);
end

function edtAreaThreshold_CreateFcn(hObject, eventdata, handles)
    if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
        set(hObject,'BackgroundColor','white');
    end
end

function edtGrayThreshold_Callback(hObject, eventdata, handles)
    handles.grayThreshold = str2double(get(hObject,'String'));
    guidata(hObject,handles);
    preview(handles,hObject);
end

function edtGrayThreshold_CreateFcn(hObject, eventdata, handles)
    if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
        set(hObject,'BackgroundColor','white');
    end

end
%% Frame Control (UI Controls & Keyboard Controls)
function sldCurrentFrame_Callback(hObject, eventdata, handles)
    handles.currentFrame = uint16(get(hObject,'Value'));
    preview(handles,hObject);
end

function sldCurrentFrame_CreateFcn(hObject, eventdata, handles)
    if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
        set(hObject,'BackgroundColor',[.9 .9 .9]);
    end
end

function btnPrevious_Callback(hObject, eventdata, handles)
    if handles.currentFrame > 1
        handles.currentFrame = handles.currentFrame - 1;
    else
        handles.currentFrame = handles.totalFrames;
    end
    preview(handles,hObject);
end

function btnNext_Callback(hObject, eventdata, handles)
    handles.currentFrame = handles.currentFrame + 1;
    if handles.currentFrame > handles.totalFrames
        handles.currentFrame =handles.totalFrames;
    end
    preview(handles,hObject);
end

function axesImage_ButtonDownFcn(hObject, eventdata, handles)
    key = get(gcf,'CurrentCharacter');
    if key == 28
        btnPrevious_Callback(hObject, eventdata, handles)
    elseif key == 29
        btnNext_Callback(hObject, eventdata, handles);
    end

end

function btnPrevious_KeyPressFcn(hObject, eventdata, handles)
    key = get(gcf,'CurrentCharacter');
    if key == 28
        btnPrevious_Callback(hObject, eventdata, handles)
    elseif key == 29
        btnNext_Callback(hObject, eventdata, handles);
    end
end

function btnNext_KeyPressFcn(hObject, eventdata, handles)
    key = get(gcf,'CurrentCharacter');
    if key == 28
        btnPrevious_Callback(hObject, eventdata, handles)
    elseif key == 29
        btnNext_Callback(hObject, eventdata, handles);
    end
end

function edtCurrentFrame_Callback(hObject, eventdata, handles)
    handles.currentFrame = floor(str2double(get(handles.edtCurrentFrame,'String')));
    if handles.currentFrame > handles.totalFrames
        handles.currentFrame =handles.totalFrames;
    end
    preview(handles,hObject);
end

function edtCurrentFrame_CreateFcn(hObject, eventdata, handles)
    if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
        set(hObject,'BackgroundColor','white');
    end
end
%% Image Type Control
function btnOriginalImage_Callback(hObject, eventdata, handles)
    global gStateControl;
    gStateControl.imageType = 1;
    preview(handles,hObject);
end

function btnBinaryImage_Callback(hObject, eventdata, handles)
    global gStateControl;
    gStateControl.imageType = 2;
    set(handles.btnSaveParams,'enable','on');
    preview(handles,hObject);
end
%% Button Trace && Show-Trace
function btnTrace_Callback(hObject, eventdata, handles)
set(handles.txtInfo,'String','Enter Tracing mode');pause(0.01);
% global color4fish;
% global coordinate;
global trackletInfo;
global gStateControl;
%% Step 01.Parameters Selection
strFileName = handles.filename;
seqName = strFileName(1:length(strFileName)-4);
grayThreshold = handles.grayThreshold;
areaThreshold = handles.areaThreshold;
cmd = [' -c ', num2str(50), ' -g ', num2str(0.01),'-q'];
warning off;
addpath('function');
addpath('function\libsvm\matlab');
tic
%% Step 02. Get file - Z.mat 
video = VideoReader(strFileName);
if ~exist('background','var')
    if ~exist([seqName,'/',seqName,'_background.mat'],'file')
        background = GetBackground(strFileName,1);
        meanValue = mean(mean(background));
        background(background > meanValue + 10) = meanValue + 10;
        handles.background = double(background);
        guidata(hObject,handles);
        save([seqName,'/',seqName,'_background.mat'],'background');
    end
end


if ~exist('Z','var')
    if ~exist([seqName,'/',seqName,'_Z.mat'],'file')
        Z = video2Z(video,grayThreshold,areaThreshold,handles);
        save([seqName,'/',seqName,'_Z.mat'],'Z');
    else
        load([seqName,'/',seqName,'_Z.mat'],'Z');
    end
end

clear areaThreshold background grayThreshold strFileName;
%% Step 03. Change file 'Z.mat' into  'fragment.mat'
if ~exist('fragment','var')
    if ~exist([seqName,'/',seqName,'_fragment.mat'],'file')
        fragment = Z2fragment(handles);
        save([seqName,'/',seqName,'_fragment.mat'],'fragment');
    end
end
clear Z;
%% Step 04. Calculate all the features for fragment
if ~exist('feature','var')   
    if ~exist([seqName,'/',seqName,'_feature.mat'],'file')
        load([seqName,'/',seqName,'_fragment.mat'],'fragment');
        
        feature = cell(1,length(fragment));
        for idx = 1:length(fragment)
            set(handles.txtInfo,'String',['fragment2feature:',num2str(idx),'/',num2str(length(fragment))]);
            % disp(['fragment2feature:',num2str(idx),'/',num2str(length(fragment))]);
            feature{idx} = fragment2feature(fragment,idx);
            pause(0.01);
        end
        save([seqName,'/',seqName,'_feature.mat'],'feature');
    end
end
%% Stop 05. Contact fragment into slice
if ~exist([seqName,'/',seqName,'_slice.mat'],'file')
    [slice,feature] = fragment2slice(handles,cmd);
    save([seqName,'/',seqName,'_slice.mat'],'slice','feature');
end
%% Step 06. Fill the coordinate
if ~exist([seqName,'/',seqName,'_coordinate.mat'],'file')
    [localCoordinate,localColor4fish] = slice2coordinate(handles,cmd);
    trackletInfo.coordinate = localCoordinate;
    trackletInfo.color4fish = localColor4fish;
    save([seqName,'/',seqName,'_coordinate.mat'],'localCoordinate','localColor4fish');
else
    load([seqName,'/',seqName,'_coordinate.mat']);
    trackletInfo.coordinate = localCoordinate;
    trackletInfo.color4fish = localColor4fish;
end
toc
%% find unsure contact
gStateControl.unsureFrame = cell(handles.numOfFishes,1);
for i = 1:size(localCoordinate,3)   
    unsure = find(localCoordinate(3,:,i)>0 & localCoordinate(3,:,i)<0.6);
    if ~isempty(unsure)
        gStateControl.unsureFrame{i} = unsure;
    end
end

set(handles.ppmCurrentCorrectionId,'String',1:handles.numOfFishes);

%% enable buttons
set(handles.txtInfo,'String','Trace Done!');
set(handles.btnShowTrace,'enable','on');
set(handles.btnPlay,'enable','on');
set(handles.btnPause,'enable','on');
set(handles.btnCorrectionPrevious,'enable','on');

set(handles.btnManuCorrection,'enable','on');
set(handles.btnConfirm,'enable','on');
set(handles.btnCancel,'enable','on');

set(handles.btnCorrectionNext,'enable','on');
set(handles.ppmCurrentCorrectionId,'enable','on');
set(handles.txtCorrectionGoTo,'enable','on');
set(handles.btnAccept,'enable','on');
end

function btnShowTrace_Callback(hObject, eventdata, handles)

    global gStateControl;

    strShowTraceOrNot = get(handles.btnShowTrace,'String');
    if strcmp(strShowTraceOrNot,'Display trace')
        set(handles.txtInfo,'String','Enter ManuCorrection Mode');
        gStateControl.bShowTrace = 1;
        set(handles.btnShowTrace,'String','Hide trace');
        DisplayPossipleMatch(handles,hObject);
    elseif strcmp(strShowTraceOrNot,'Hide trace')
        set(handles.txtInfo,'String','Quit ManuCorrection Mode');
        gStateControl.bShowTrace = 0;
        set(handles.btnShowTrace,'String','Display trace');
        preview(handles,hObject);
    end
    
end
%% Save Params
function btnSaveParams_Callback(hObject, eventdata, handles)
    filename = [handles.filepath,'/',handles.seqName,'/',handles.seqName,'_Params.mat'];
    
    image = read(handles.video,handles.currentFrame);
    image = rgb2gray(image);
    meanValue = mean(mean(image));
    image(image>meanValue +5) = meanValue;
    imgBinary = abs(double(image) - double(handles.background))...
        > handles.grayThreshold;
    some = regionprops(imgBinary,'area','Orientation','BoundingBox','Centroid');
    toFill = some([some.Area] < [handles.areaThreshold],:);
    for k = 1:size(toFill,1)
        row = round(toFill(k).BoundingBox(2));
        col = round(toFill(k).BoundingBox(1));
        for i = row:row + toFill(k).BoundingBox(4)
            for j = col : col + toFill(k).BoundingBox(3)
                imgBinary(i,j) = 0;
            end
        end
    end
    [~,numOfFishes] = bwlabel(imgBinary);
    handles.numOfFishes = numOfFishes;
    
    grayThreshold = handles.grayThreshold;
    areaThreshold = handles.areaThreshold;
%     numOfFishes = handles.numOfFishes;
    video = handles.video;
    save(filename,'grayThreshold','areaThreshold','numOfFishes','video');
    set(handles.lstID,'String',1:numOfFishes);
    set(handles.lstID,'Value',[]);
    set(handles.txtInfo,'String','Save Param successfully.');
    btnOriginalImage_Callback(hObject, eventdata, handles);
end
%% WindowScrollWheelFcn & WindowButtonMotionFcn & WindowButtonUp
function figure1_WindowScrollWheelFcn(hObject, eventdata, handles)
    currentMousePoint = get(gca,'CurrentPoint');
    currentMousePoint = currentMousePoint(1,1:2);
    xlimValue = get(gca,'XLim');
    ylimValue = get(gca,'YLim');
    fact = 2;
    if eventdata.VerticalScrollCount < 0
        fact = 1./fact;
    end
    xlimValueNew = (xlimValue - currentMousePoint(1,1))*fact + currentMousePoint(1,1);
    ylimValueNew = (ylimValue - currentMousePoint(1,2))*fact + currentMousePoint(1,2);
    xlim(xlimValueNew);
    ylim(ylimValueNew);
end

function figure1_WindowButtonMotionFcn(hObject, eventdata, handles)
    global gStateControl;
    currentMousePoint = get(gca,'CurrentPoint');
    currentMousePoint = currentMousePoint(1,1:2);
    if ~isempty(gStateControl.currentMousePosition) && gStateControl.button == 2
        xlimValue = get(gca,'XLim');
        ylimValue = get(gca,'YLim');
        xlimValueNew = xlimValue + (gStateControl.currentMousePosition(1) - currentMousePoint(1));
        ylimValueNew = ylimValue + (gStateControl.currentMousePosition(2) - currentMousePoint(2));
        xlim(xlimValueNew);
        ylim(ylimValueNew);
        gStateControl.currentMousePosition = currentMousePoint;
    end
end

function figure1_WindowButtonUpFcn(hObject, eventdata, handles)
    global gStateControl;
    gStateControl.currentMousePosition = [];
    gStateControl.button = 0;
end

function figure1_WindowButtonDownFcn(hObject, eventdata, handles)
end
%% Button ManuCorrection & Confirm & Cancel
function btnConfirm_Callback(hObject, eventdata, handles)
    global gStateControl;
    global trackletInfo;
    
    correctionMatch = gStateControl.correctionMatch;
    if size(correctionMatch,2) > handles.numOfFishes
        set(handles.txtInfo,'String','The matches are too many, please check!');
    elseif isempty(correctionMatch)
        % do nothing
    else
        set(handles.txtInfo,'String','Matching...');
        if gStateControl.correctionMode == 1
            match = gStateControl.correctionMatchLabel;
            if ~all(match > 0) || ~all(match <= handles.numOfFishes)
                return;
            end
            currentCorrectionId = double(get(handles.ppmCurrentCorrectionId,'Value'));
            unsure = gStateControl.unsureFrame{currentCorrectionId};
            currentIdx = str2double(get(handles.txtCorrectionGoTo,'String'));
            currentFrame = max([unsure(currentIdx),1]);
            currentEnd = currentFrame + trackletInfo.coordinate(4,currentFrame,currentCorrectionId);

            for kk = 1:size(match,2)
                coor = trackletInfo.coordinate(:,currentFrame:currentEnd,match(kk,1));
                trackletInfo.coordinate(:,currentFrame:currentEnd,match(1,kk)) = trackletInfo.coordinate(:,currentFrame:currentEnd,match(2,kk));
                trackletInfo.coordinate(:,currentFrame:currentEnd,match(2,kk)) = coor;
            end
            set(handles.txtInfo,'String','Correction Mode 01����Manual correction');
            
        elseif gStateControl.correctionMode == 2
            set(handles.txtInfo,'String','Correction Mode 02����Link trace');
        elseif gStateControl.correctionMode == 0
            set(handles.txtInfo,'String','Correction Mode 00����Manual correction��OFF');
        end
    end
    gStateControl.correctionMatch = [];
    gStateControl.correctionIndex = 1;
    gStateControl.correctionMatchLabel = [];
    preview(handles,hObject);
end

function btnCancel_Callback(hObject, eventdata, handles)
    global gStateControl;
    gStateControl.correctionMatch = [];
    gStateControl.correctionIndex = 1;
    gStateControl.correctionMatchLabel = [];
    preview(handles,hObject);
end

function btnManuCorrection_Callback(hObject, eventdata, handles)
    global gStateControl;
    global trackletInfo;
    strMode = get(handles.btnManuCorrection,'String');
    if strcmp(strMode,'Manual correction��OFF')
        set(handles.btnConfirm,'enable','on');
        set(handles.btnCancel,'enable','on');
        gStateControl.correctionMode = 1;
        set(handles.btnManuCorrection,'String','Manual correction');
    elseif strcmp(strMode,'Manual correction')
        gStateControl.correctionMode = 2;
%         handles.currentFrame = trackletInfo.ZITL(handles.numOfFishes + 2).t_start - 1;
        guidata(hObject,handles);
        set(handles.btnManuCorrection,'String','Link trace');
    elseif strcmp(strMode,'Link trace')
        gStateControl.correctionMode = 0;
        set(handles.btnManuCorrection,'String','Manual correction��OFF');
        set(handles.btnConfirm,'enable','off');
        set(handles.btnCancel,'enable','off');
    end
    preview(handles,hObject);
        
end
%% Buuton Play & save as video 
function btnPlay_Callback(hObject, eventdata, handles)

    global gStateControl;
    gStateControl.bPause = 0;
    WriterObj=VideoWriter([handles.filepath,'\',handles.seqName,'\',handles.seqName,'_Track.avi']);%���ϳɵ���Ƶ
    WriterObj.FrameRate=13;% before open to set the frameRate
    open(WriterObj);
    % ѭ������ǰ֡��һ������Ԥ�������bPause == 0����ֹͣ����
    while handles.currentFrame < handles.totalFrames && gStateControl.bPause == 0
        handles.currentFrame = handles.currentFrame + 1;
        if handles.currentFrame > handles.totalFrames
            handles.currentFrame =handles.totalFrames;
        end
        preview(handles,hObject);
%         axes(handles.axesImage);
%         if isempty(handles.axesImage)
%             return;
%         end
%         newFig = figure;%����ֱ�ӱ���axes1�ϵ�ͼ�������ѣ����Ա������½���figure�е���ͼ
%         set(newFig,'Visible','off')%�����½���figureΪ���ɼ�
%         newAxes = copyobj(handles.axesImage,newFig);   %��axes1�е�ͼ���Ƶ��½���figure��
%         set(newAxes,'Units','default','Position','default');    % ����ͼ��ʾ��λ��
%         f = getframe(newFig);
%         f = frame2im(f);
%         writeVideo(WriterObj,f);% ��frame�ŵ�����WriterObj��
    end
    
    close(WriterObj);
    
    

end
%% Button pause
function btnPause_Callback(hObject, eventdata, handles)
    global gStateControl;
    gStateControl.bPause = 1;
end
%% List lstID
function lstID_Callback(hObject, eventdata, handles)
    global gStateControl;
    ids = get(handles.lstID,'Value');
    gStateControl.id4fish2show = ids;
    preview(handles,hObject);
end

function lstID_CreateFcn(hObject, eventdata, handles)
    if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
        set(hObject,'BackgroundColor','white');
    end
end
%% Location
function ppmCurrentCorrectionId_Callback(hObject, eventdata, handles)
    global gStateControl;
    selection = double(get(handles.ppmCurrentCorrectionId,'Value'));
    disp(gStateControl.unsureFrame);
    set(handles.txtCorrectionTotal,'String',length(gStateControl.unsureFrame{selection}));
    set(handles.txtCorrectionGoTo,'String',0);
    txtCorrectionGoTo_Callback(hObject, eventdata, handles);
end
function ppmCurrentCorrectionId_CreateFcn(hObject, eventdata, handles)

    if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
        set(hObject,'BackgroundColor','white');
    end
end
function btnCorrectionNext_Callback(hObject, eventdata, handles)
    global gStateControl;
    current = str2double(get(handles.txtCorrectionGoTo,'String')) + 1;
    currentCorrectionId = double(get(handles.ppmCurrentCorrectionId,'Value'));
    len = length(gStateControl.unsureFrame{currentCorrectionId});
    if len == 0
        return;
    elseif current > len
        current = len;
    end
    unsure = gStateControl.unsureFrame{currentCorrectionId};
    handles.currentFrame = max([unsure(current)-1,1]);
    preview(handles,hObject);
    set(handles.txtCorrectionGoTo,'String',current);
end
function btnCorrectionPrevious_Callback(hObject, eventdata, handles)
        global gStateControl;
    current = str2double(get(handles.txtCorrectionGoTo,'String')) - 1;
    currentCorrectionId = double(get(handles.ppmCurrentCorrectionId,'Value'));
    len = length(gStateControl.unsureFrame{currentCorrectionId});
    if len == 0
        return;
    elseif current < 1
        current = 1;
    end
    unsure = gStateControl.unsureFrame{currentCorrectionId};
    handles.currentFrame = max([unsure(current)-1,1]);
    preview(handles,hObject);
    set(handles.txtCorrectionGoTo,'String',current);
end
function txtCorrectionGoTo_Callback(hObject, eventdata, handles)
    global gStateControl;
    current = str2double(get(handles.txtCorrectionGoTo,'String'));
    currentCorrectionId = double(get(handles.ppmCurrentCorrectionId,'Value'));
    len = length(gStateControl.unsureFrame{currentCorrectionId});
    if len == 0
        return;
    elseif current > len
        current = len;
    elseif current < 1
        current = 1;
    end
    unsure = gStateControl.unsureFrame{currentCorrectionId};
    handles.currentFrame = max([unsure(current)-1,1]);
    preview(handles,hObject);
    set(handles.txtCorrectionGoTo,'String',current);
end
function txtCorrectionGoTo_CreateFcn(hObject, eventdata, handles)
    if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
        set(hObject,'BackgroundColor','white');
    end
end
function txtCorrectionTotal_Callback(hObject, eventdata, handles)
end
function txtCorrectionTotal_CreateFcn(hObject, eventdata, handles)
    if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
        set(hObject,'BackgroundColor','white');
    end
end
%% Button Accept
function btnAccept_Callback(hObject, eventdata, handles)
    global gStateControl;
    current = str2double(get(handles.txtCorrectionGoTo,'String'));
    currentCorrectionId = double(get(handles.ppmCurrentCorrectionId,'Value'));
    unsure = gStateControl.unsureFrame{currentCorrectionId};
    unsure(current) = [];
    gStateControl.unsureFrame{currentCorrectionId}= unsure;
    btnCorrectionPrevious_Callback(hObject, eventdata, handles);
    ppmCurrentCorrectionId_Callback(hObject, eventdata, handles);
end


function rbOfflineModel_ButtonDownFcn(hObject, eventdata, handles)

end


function rbOnlineModel_ButtonDownFcn(hObject, eventdata, handles)
    
end


function rbOnlineModel_Callback(hObject, eventdata, handles)
    global gStateControl;
    gStateControl.Online_Offline_Model = 0;
end


function rbOfflineModel_Callback(hObject, eventdata, handles)
    global gStateControl;
    gStateControl.Online_Offline_Model = 1;
end
