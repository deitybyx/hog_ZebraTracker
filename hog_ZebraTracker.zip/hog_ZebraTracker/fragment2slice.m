function [slice,feature] = fragment2slice(handles,cmd)
set(handles.txtInfo,'String','fragment2slice...');pause(0.01);
seqName = handles.seqName;
numOfFishes = handles.numOfFishes;
load([seqName,'/',seqName,'_feature.mat']);
load([seqName,'/',seqName,'_fragment.mat']);

addpath('function');
addpath('function/libsvm/matlab');
currentIndex = numOfFishes+1;

if isfield(fragment,'imageCroped')
    for i = 1:length(fragment)
        fragment(i).effectiveLength = length(fragment(i).imageCroped);
    end
    fragment = rmfield(fragment,'imageCroped');
end


%% 
while currentIndex < length(fragment)
    set(handles.txtInfo,'String',['fragment2slice - ',num2str(currentIndex/length(fragment))]);pause(0.01);
    currentValue = fragment(currentIndex).t_start;
    if currentValue == 1031
    end
    idxPredict = find([fragment.t_start] == currentValue);
    idxTrain = find([fragment.t_end] == currentValue-1);
    bToContinue = 1;
    for idx = [idxTrain,idxPredict]
        if fragment(idx).effectiveLength < 10 || isempty(feature{idx})
            bToContinue = 0;
            break;
        end
    end

    if length(idxTrain) == length(idxPredict) && bToContinue == 1
        %% train a model
        label4train = [];
        feature4train = [];
        
        % decide which fragment to be used in training a model
        lengthTrain = fragment(idxTrain).effectiveLength;
        lengthPredict = fragment(idxPredict).effectiveLength;
        
        if min(lengthTrain) > min(lengthPredict)
        
            for idx = idxTrain
                feature4train = [feature4train;feature{idx}];
                label4train = [label4train;ones(size(feature{idx},1),1)*idx];
            end
            model = libsvmtrain(label4train,feature4train,cmd);

            %% prediction
            prediction = zeros(length(idxPredict),length(idxTrain));
            idxOmit = zeros(size(idxPredict));
            for idx= 1:length(idxPredict)
                if fragment(idxPredict(idx)).effectiveLength > 10
                    label4predict = zeros(size(feature{idxPredict(idx)},1),1);
                    predict_left = libsvmpredict(label4predict,feature{idxPredict(idx)},model);
                    pre = hist(predict_left,idxTrain);
                    if currentValue == 2955 
                    end
                    prediction(idx,:) = pre./sum(pre);
                else
                    idxOmit(idx) = idxPredict(idx);
                end
            end
        else
            for idx = idxPredict
                feature4train = [feature4train;feature{idx}];
                label4train = [label4train;ones(size(feature{idx},1),1)*idx];
            end
            model = libsvmtrain(label4train,feature4train,cmd);

            %% prediction
            prediction = zeros(length(idxPredict),length(idxTrain));
            idxOmit = zeros(size(idxPredict));
            for idx= 1:length(idxTrain)
                if fragment(idxTrain(idx)).effectiveLength > 10
                    label4predict = zeros(size(feature{idxTrain(idx)},1),1);
                    predict_left = libsvmpredict(label4predict,feature{idxTrain(idx)},model);
                    pre = hist(predict_left,idxTrain)';

                    prediction(:,idx) = pre./sum(pre);
                end
            end
        end

        [predict_left,value] = Hungarian(-prediction);
        [prediction_sorted,sorted_index] = sort(prediction,2,'descend');
        if length(sorted_index(:,1)) == length(unique(sorted_index(:,1))) &&  all(prediction_sorted(:,1) > 1/length(prediction))
            %% Mark
            predict_left = mod(find(predict_left')-1,length(prediction))+1;
            for idx = 1 :length(predict_left)
                fragment(idxTrain(predict_left(idx))).t_end = fragment(idxPredict(idx)).t_end;
                fragment(idxTrain(predict_left(idx))).centerCoor = [fragment(idxTrain(predict_left(idx))).centerCoor,fragment(idxPredict(idx)).centerCoor];
                if idxOmit(idx) == 0
                    feature{idxTrain(predict_left(idx))} = [feature{idxTrain(predict_left(idx))};feature{idxPredict(idx)}];
                end
            end
            feature(idxPredict) = [];
            fragment(idxPredict) = [];
        else
            currentIndex = currentIndex + length(idxPredict);
        end
    else
        currentIndex = currentIndex + length(idxPredict);
    end
end

%% drop those whose effictive length is less than 10
filter = [fragment.effectiveLength] <= 10;
fragment(filter) = [];
feature(filter) = [];
slice = fragment;
% currentIndex = numOfFishes + 1;
% while currentIndex < length(fragment)
%     if all([fragment(currentIndex).effectiveLength] < 10)
%         fragment(currentIndex) = [];
%         feature(currentIndex) = [];
%     else
%         currentIndex = currentIndex + 1;
%     end
% end
% for i = 1:length(fragment)
%     fragment(i).effectiveLength = fragment(i).t_end - fragment(i).t_start + 1;
% end
end