function DisplayPossipleMatch(handles,hObject)
%% Diserted
%     global fragment;
%     global slice;
%     global color4fish;
%     global coordinate;
%     global gStateControl;
%     if isempty(coordinate)
%         return;
%     end
% %     hold on;n = 14;plot(fragment(n).centerCoor(1,:),fragment(n).centerCoor(2,:),'*r')
% %     
% %     index = 127;
% %     endFrame = handles.currentFrame - fragment(index).t_start + 1;
% %     startFrame = max(endFrame - 30,1);
% %     coor = fragment(index).centerCoor(:,startFrame:endFrame);
% %     coor = coor(:,~all(coor==-1,1));
% %     hold on;
% %     if ~isempty(coor)
% %         plot(coor(1,:),coor(2,:),'-','LineWidth',3);
% %     end
% 
%     id4fish2show = gStateControl.id4fish2show;
%     if isempty(id4fish2show)
%         id4fish2show = 1:handles.numOfFishes;
%     end
%     endFrame = handles.currentFrame;
%     startFrame = max(endFrame - 30,1);
%     for index = id4fish2show
%         coor =coordinate(1:2,startFrame:endFrame,index);
%         coor = coor(:,~all(coor==-1,1));
%         coor = coor(:,~all(coor==0,1));
%         hold on;
%         if ~isempty(coor)
%             plot(coor(1,:),coor(2,:),'-','Color',color4fish(index,:),'LineWidth',3);
%             text(coor(1,end),coor(2,end),['(',num2str(index),')'],'FontSize',14);
%         end
%     end

%% Remain
    global slice;
%     hold on;n = 3;plot(slice(n).centerCoor(1,:),slice(n).centerCoor(2,:),'*g');
%     hold on;n = 31;plot(slice(n).centerCoor(1,:),slice(n).centerCoor(2,:),'*r');
%     hold on;n = 43;plot(slice(n).centerCoor(1,:),slice(n).centerCoor(2,:),'*b');

    global fragment;
%     hold on;n = 69;plot(fragment(n).centerCoor(1,:),fragment(n).centerCoor(2,:),'*g')
%     hold on;n = 85;plot(fragment(n).centerCoor(1,:),fragment(n).centerCoor(2,:),'*r')
    
    global gStateControl;
    global trackletInfo;
    if isempty(trackletInfo.coordinate);
        return;
    end
    hold on;
    lengthToShow = 20;
     id4fish2show = gStateControl.id4fish2show;
     if isempty(id4fish2show)
         id4fish2show = 1:handles.numOfFishes;
     end
    if gStateControl.correctionMode == 0
        % �˹�����
        endFrame = handles.currentFrame;
        startFrame = max(endFrame - lengthToShow,1);

        for i = id4fish2show
            coordinate = trackletInfo.coordinate(1:2,startFrame:endFrame,i);
%             coordinate = coordinate(:,~all(coordinate == -1,1)& ~all(coordinate == 0,1));
            coordinate = coordinate(:,all(coordinate > 0,1));
            if ~isempty(coordinate)
                handle = plot(coordinate(1,:),coordinate(2,:),'-','Color',trackletInfo.color4fish(i,:),'LineWidth',5);
%                 set(handle,'ButtonDownFcn',{@keydown_fcn,handles,hObject});
                handle = text(coordinate(1,end),coordinate(2,end),['�� ',num2str(i)],'FontSize',16);
%                 set(handle,'ButtonDownFcn',{@keydown_fcn,handles,hObject});
%                 handle = text(coordinate(1,1),coordinate(2,1),['@ ',num2str(i)],'FontSize',16);
%                 set(handle,'ButtonDownFcn',{@keydown_fcn,handles,hObject});
            end
        end
%         saveas(gcf, [handles.filepath,'\',handles.seqName,'\',handles.seqName,'.bmp'], 'bmp');

    elseif gStateControl.correctionMode == 1
        % ��ʾ֮ǰ�ļ�����
        endFrame = handles.currentFrame;
        startFrame = max(endFrame - lengthToShow,1);
        for i = id4fish2show
            coordinate = trackletInfo.coordinate(1:2,startFrame:endFrame,i);
%             coordinate = coordinate(:,~all(coordinate == -1,1)& ~all(coordinate == 0,1));
            coordinate = coordinate(:,all(coordinate > 0,1));
            if ~isempty(coordinate)
                handle = plot(coordinate(1,:),coordinate(2,:),'-','Color',trackletInfo.color4fish(i,:),'LineWidth',5);
                %         handle = plot(hGUIFigure1.ZITL(i).data(1,startFrame:endFrame),hGUIFigure1.ZITL(i).data(2,startFrame:endFrame),...
                %             '-','Color',hGUIFigure1.color4Fish(i,:),'LineWidth',5);
                set(handle,'ButtonDownFcn',{@keydown_fcn,handles,hObject});
                handle = text(coordinate(1,end),coordinate(2,end),['�� ',num2str(i)],'FontSize',16);
                set(handle,'ButtonDownFcn',{@keydown_fcn,handles,hObject});
                handle = text(coordinate(1,1),coordinate(2,1),['�� ',num2str(i)],'FontSize',16);
                %         handle = text(hGUIFigure1.ZITL(i).data(1,endFrame),hGUIFigure1.ZITL(i).data(2,endFrame),...
                %             ['@ ',num2str(i)],'FontSize',16);
                set(handle,'ButtonDownFcn',{@keydown_fcn,handles,hObject});
            end
        end
        % ��ʾ֮��ļ�����
        startFrame = handles.currentFrame;
        endFrame = min(startFrame + 3,handles.totalFrames);
        for i = id4fish2show
            coordinate = trackletInfo.coordinate(1:2,startFrame:endFrame,i);
%             coordinate = coordinate(:,~all(coordinate == -1,1)& ~all(coordinate == 0,1));
            coordinate = coordinate(:,all(coordinate > 0,1));
            if ~isempty(coordinate)
                handle = plot(coordinate(1,:),coordinate(2,:),'-','Color',trackletInfo.color4fish(i,:),'LineWidth',5);
                set(handle,'ButtonDownFcn',{@keydown_fcn,handles,hObject});
                handle = text(coordinate(1,end),coordinate(2,end),['�� ',num2str(i)],'FontSize',16);
                set(handle,'ButtonDownFcn',{@keydown_fcn,handles,hObject});
                handle = text(coordinate(1,1),coordinate(2,1),['�� ',num2str(i)],'FontSize',16);
                set(handle,'ButtonDownFcn',{@keydown_fcn,handles,hObject});
            end
        end
    elseif gStateControl.correctionMode == 2
        index = handles.numOfFishes + 1;
        if length(trackletInfo.ZITL)<index
            % ���ZITL�Ĺ켣���Ѿ�С�ڵ��������Ŀ��������Ҫ�켣ƴ��
            return;
        end
        coordinate = trackletInfo.ZITL(index).data;
        if isempty(coordinate)
            disp('The tracklet is empty! Delete it and return');
            return;
        end
        handle = plot(coordinate(1,:),coordinate(2,:),'*','Color',rand(3,1),'LineWidth',5);
        set(handle,'ButtonDownFcn',{@keydown_fcn,handles,hObject});
        
        set(handle,'ButtonDownFcn',{@keydown_fcn,handles,hObject});
        handle = text(coordinate(1,end),coordinate(2,end),[num2str(index),'�� ',num2str(trackletInfo.ZITL(index).t_start)],'FontSize',16);
        set(handle,'ButtonDownFcn',{@keydown_fcn,handles,hObject});
        handle = text(coordinate(1,1),coordinate(2,1),[num2str(index),'�� ',num2str(trackletInfo.ZITL(index).t_end)],'FontSize',16);
        set(handle,'ButtonDownFcn',{@keydown_fcn,handles,hObject});
        
        endFrame = handles.currentFrame;
        startFrame = max(endFrame - lengthToShow,1);
        for i = id4fish2show
            coordinate = trackletInfo.coordinate(:,startFrame:endFrame,i);
%             coordinate = coordinate(:,~all(coordinate == -1,1));
            coordinate = coordinate(:,all(coordinate > 0,1));
            if ~isempty(coordinate)
                handle = plot(coordinate(1,:),coordinate(2,:),'-','Color',trackletInfo.color4Fish(i,:),'LineWidth',5);
                set(handle,'ButtonDownFcn',{@keydown_fcn,handles,hObject});
                handle = text(coordinate(1,end),coordinate(2,end),['�� ',num2str(i)],'FontSize',16);
                set(handle,'ButtonDownFcn',{@keydown_fcn,handles,hObject});
                handle = text(coordinate(1,1),coordinate(2,1),['�� ',num2str(i)],'FontSize',16);
                set(handle,'ButtonDownFcn',{@keydown_fcn,handles,hObject});
            end
        end
    end
    
end
