function [coordinate,color4fish] = slice2coordinate(handles,cmd)
global gStateControl;
seqName = handles.seqName;
numOfFishes = handles.numOfFishes;
%%
load([seqName,'/',seqName,'_slice.mat']);

color4fish = jet(numOfFishes); % decide the color type
coordinate = zeros(4,max([slice.t_end]),numOfFishes);   % coordinate(1,:) - x, coordinate(2,:) - y, coordinate (3,:) - acception rate

if isfield(slice,'imageCroped')
    slice = rmfield(slice,'imageCroped');
end

for idx = 1:length(slice)
    slice(idx).length = slice(idx).t_end - slice(idx).t_start + 1;
end
%% Train or Load a model
if gStateControl.Online_Offline_Model == 1
    load('model.mat');
    set(handles.txtInfo,'String','slice2coordinate: Loading offline model');pause(0.01);
else
    %% Decide which slices are used for model
    set(handles.txtInfo,'String','slice2coordinate: Decide which slices are used for model');pause(0.01);
    % disp('slice2coordinate: Decide which slices are used for model');
    length4fishes = zeros(numOfFishes,max([slice.t_end]));
    currentIdxForEachLine = zeros(numOfFishes,1);
    for idx = 1 :length(slice)
        [~,index] = min(currentIdxForEachLine);
        length4fishes(index,slice(idx).t_start:slice(idx).t_end) = slice(idx).effectiveLength;
        currentIdxForEachLine(index) = slice(idx).t_end;
        %     disp(slice(idx).length);
    end
    clear currentIdxForEachLine;
    
    [~,maxIndex] = max(min(length4fishes));
    index4model = zeros(numOfFishes,1);
    index = 1;
    for idx = 1 :length(slice)
        if slice(idx).t_start <= maxIndex && slice(idx).t_end >= maxIndex
            index4model(index) = idx;
            index = index + 1;
            if index > numOfFishes
                break;
            end
        end
    end
    %% Train model
    set(handles.txtInfo,'String','slice2coordinate: Training model');pause(0.01);
    
    if exist([seqName,'/',seqName,'_modelAll.mat'],'file')
        load([seqName,'/',seqName,'_modelAll.mat']);
    else
        label4train = [];
        feature4train = [];
        for idx = 1:length(index4model)
            feature4train = [feature4train;feature{index4model(idx)}];
            label4train = [label4train;ones(size(feature{index4model(idx)},1),1)*idx];
        end
        model = libsvmtrain(label4train,feature4train,cmd);
        save([seqName,'/',seqName,'feature4train.mat'],'feature4train','label4train');
        save([seqName,'/',seqName,'_modelAll.mat'],'model');
    end
end
%% Calculate predition
set(handles.txtInfo,'String','slice2coordinate: Calculate predition');pause(0.01);

prediction = zeros(length(slice),numOfFishes);
if exist([seqName,'/',seqName,'_slicePrediction.mat'],'file')
    load([seqName,'/',seqName,'_slicePrediction.mat']);
else
    for idx = 1:length(slice)
    set(handles.txtInfo,'String',['slice2coordinate: Calculate predition - ',num2str(idx),'/',num2str(length(slice))]);pause(0.01);
        label = zeros(size(feature{idx},1),1);
        if ~isempty(label)
            predict = libsvmpredict(label,feature{idx},model);
            count = hist(predict,1:numOfFishes);
            prediction(idx,:) = count./sum(count);
        end
    end
    save([seqName,'/',seqName,'_slicePrediction.mat'],'prediction'); %length(slice)*numOfFish
end
set(handles.txtInfo,'String','slice2coordinate: Fill coordinate');pause(0.01);
%% Fill coordinate
currentEnd = zeros(numOfFishes,1);
while ~isempty(slice)

    currentEnd_sorted = sort(currentEnd);
    t_start = [slice.t_start];
   
    idxToOperate = t_start > currentEnd_sorted(1) & t_start <= currentEnd_sorted(end);
    
    t_end = [slice.t_end];
    if sum(idxToOperate) > 0
        idx4match = currentEnd < min(t_end);
    else
        idx4match = ones(numOfFishes,1);
    end
    idxToOperate = (t_start < min(t_end)); %ʱ���ϵ

    if sum(idx4match) == 1 && sum(idxToOperate) == 1
        currentEnd(idx4match) = slice(idxToOperate).t_end;
%         coordinate(1:2,slice(idxToOperate).t_start:...
%             slice(idxToOperate).t_end,idx4match) = slice(idxToOperate).centerCoor;
        coordinate(1:2,slice(idxToOperate).t_start:...
            slice(idxToOperate).t_end,idx4match) = slice(idxToOperate).centerCoor;
        coordinate(3,slice(idxToOperate).t_start,idx4match) = 1;
    else
        predict = -prediction(idxToOperate,:);
        if sum(idx4match) ~= numOfFishes
            predict(:,~idx4match) = 0;
            for i = 1:size(predict,1)
                if sum(predict(i,:)) ~= 0
                    predict(i,:) = -predict(i,:)./sum(predict(i,:));
                end
            end
        end
        predict_left = KM(predict);
        index4operation = find(idxToOperate);
        for idx = 1:length(predict_left)
            if all(coordinate(:,slice(index4operation(idx)).t_start:slice(index4operation(idx)).t_end,predict_left(idx)) == 0)
                coordinate(1:2,slice(index4operation(idx)).t_start:...
                    slice(index4operation(idx)).t_end,predict_left(idx)) = slice(index4operation(idx)).centerCoor;
%                 coordinate(3,slice(index4operation(idx)).t_start,predict_left(idx)) = -predict(idx,predict_left(idx))*size(predict,1)/2;
%                 coordinate(4,slice(index4operation(idx)).t_start,predict_left(idx)) = slice(index4operation(idx)).t_end - slice(index4operation(idx)).t_start;
%                 coordinate(3,slice(index4operation(idx)).t_start:slice(index4operation(idx)).t_end,predict_left(idx)) = predict(idx,predict_left(idx))/sum(predict(idx,:));
                coordinate(3,slice(index4operation(idx)).t_start,predict_left(idx)) =predict(idx,predict_left(idx))/sum(predict(idx,:));
                currentEnd(predict_left(idx)) = slice(index4operation(idx)).t_end;
            end
        end
    end
    slice(idxToOperate) = [];
    prediction(idxToOperate,:) = [];
end

end