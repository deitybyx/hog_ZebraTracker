se = zeros(size(fragment,1),2);
fragmentStruct = [fragment{:}]';
se(:,1) = [fragmentStruct(:).t_start];
se(:,2) = [fragmentStruct.t_end];
se = se';
