function feature = fragment2feature(fragment,index)
%     disp(['fragment2feture:',num2str(index),'/',num2str(length(fragment))]);
    nLength = 100;
    feature = [];
    for j = 1:length(fragment(index).imageCroped)
        if ~isempty(fragment(index).imageCroped{j})
            
            
            %%
            img = fragment(index).imageCroped{j};
            [nHeight,nWidth,~] = size(img);
%             img = img(nHeight,ceil(nWidth/2):end);
            img = scale(img,nLength,nLength);
            
            [nHeight,nWidth,~] = size(img);
            img = padarray(img,[ceil((nLength - nHeight)/2) ceil((nLength - nWidth)/2)], 255);
            feature = [feature;HOG_Feature(img,9)];
            %%
%             img = scale(fragment(index).imageCroped{j},100,100);
%             [nHeight,nWidth,~] = size(img);
%             img = padarray(img,[ceil((100 - nHeight)/2) ceil((100 - nWidth)/2)], 255);
%             feature = [feature;HOG_Feature(img,9)];
        end
    end
    
end