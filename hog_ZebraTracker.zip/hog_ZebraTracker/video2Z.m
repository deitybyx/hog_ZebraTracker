function [Z,numOfFishes] = video2Z(video,grayThreshold,areaThreshold,handles)
    seqName = handles.seqName;
    load([seqName,'/',seqName,'_background.mat'],'background');
    background = double(background);
    
    totalFrames = video.NumberOfFrames;
    tam = [video.Height,video.Width];
    X = repmat(1:tam(2),[tam(1) 1]);%�����������1:tam(2)�ľ������ݶѵ���[tam(1) 1]�У����վ����С1*tam(1)��tam(2)*1
    Y = repmat((1:tam(1))',[1 tam(2)]);
    
    % alloct space
    Z = struct('centerCoor',[],'imageCroped',[]);
    Z(1,totalFrames).centerCoor = [];
    numOfFishes = 0;
    
%     folder = 'OriginalPic';
%     if ~exist(folder,'dir')
%         dos(['mkdir ',folder]);
%     end
    meanValue = [];
    for frame_act=1:totalFrames %num
        set(handles.txtInfo,'String',['video2Z:  ' num2str(frame_act) '/' num2str(totalFrames)]);
%         disp(['video2Z:  ' num2str(frame_act) '/' num2str(totalFrames)]);
        frame=read(video,frame_act);
        if size(frame,3)==3
            frame =rgb2gray(frame);
        end
        if isempty(meanValue)
            meanValue = mean(mean(frame));
        end
        frame(frame>meanValue + 10) = meanValue + 10;
        
        frame_doub=double(frame); %��Ƶ��С
        imgFilter2D=abs(frame_doub-background)>grayThreshold;%�Ҷ���ֵ
        
        % ��Բ���
        manchas=bwconncomp(imgFilter2D); %���������㷨�õ�Ŀ������
        tams=cellfun(@(x) length(x),manchas.PixelIdxList);%��Ԫ������manchas.PixelIdxListÿ��Ԫ���ĳ��ȣ�length(x)
        % ɸѡ������� areaThreshold �Ĳ���
        listapixels=manchas.PixelIdxList(tams > areaThreshold);
        

        if length(listapixels)>numOfFishes
            numOfFishes = length(listapixels);
        end
        
        for c_buenos=1:length(listapixels)

            imgFilter2D=false(manchas.ImageSize);%�����߼�0����
            imgFilter2D(listapixels{c_buenos})=true;%����ֵΪ1
%             ind=find(imgFilter2D);       %���ط���Ԫ������λ��
            x = X(imgFilter2D);
            y = Y(imgFilter2D);
            lim=[min(x) max(x) min(y) max(y)];

            
            [coorX,coorY,~,~,theta,axisLong,axisShort]=minOuterRect(imgFilter2D,0);
            Z(frame_act).centerCoor(:,c_buenos)= [sum(coorX(1:4,:))/4,sum(coorY(1:4,:))/4];     % ��������
            if axisLong/axisShort >3
                %% ������ͷ�ķ���
                [nRow,nCol,~] = size(imgFilter2D);
                if theta < 45 && theta>-45        % ���ҵ���
                    nSumLeft = sum(sum(imgFilter2D(:,1:floor(Z(frame_act).centerCoor(1,c_buenos))),1),2);                          % ͳ�Ƶ�Ŀ���ֵ
                    nSumRight = sum(sum(imgFilter2D(:,[ceil(Z(frame_act).centerCoor(1,c_buenos)):nCol]),1),2);
                    theta = mod(theta+360,360);
                    if(nSumLeft > nSumRight)    % left
                        if theta < 90
                            theta = theta + 180;
                        elseif theta > 270
                            theta = theta - 180;
                        end
                    else                        % right
                        if theta >= 180 && theta < 270
                            theta = theta-180;
                        elseif theta < 180 && theta > 90
                            theta = theta +180;
                        end
                    end
                else % ���·������
                    nSumUp = sum(sum(imgFilter2D(1:floor(Z(frame_act).centerCoor(2,c_buenos)),:),1),2);
                    nSumDown = sum(sum(imgFilter2D(ceil(Z(frame_act).centerCoor(2,c_buenos)):nRow,:),1),2);
                    theta = mod(theta+360,360);
                    if(nSumUp > nSumDown)   % up
                        if theta > 180
                            theta = theta - 180;
                        end
                    else                    % down
                        if theta < 180
                            theta = theta + 180;
                        end
                    end
                end
                

                % Get the head part without background
                imgFrame=frame;
                imgFrame(~imgFilter2D)=255;
                imgFrame = imgFrame(lim(3):lim(4),lim(1):lim(2));
                imgFrame = imrotate(255-imgFrame,-theta,'bilinear');
                img = NonZeroSubImg(255 - imgFrame,255);
                imgFrame = img(:,floor(size(img,2)/2):size(img,2));
%                 imwrite(imgFrame,[folder,'/',num2str(frame_act),'_',num2str(c_buenos),'.jpg']);
                Z(frame_act).imageCroped{c_buenos}=imgFrame;
            else
                Z(frame_act).imageCroped{c_buenos} = [];
            end
        end
    end
end



