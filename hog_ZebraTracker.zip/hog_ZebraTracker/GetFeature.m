function [feature] = GetFeature(strFilePath,background,grayThreshold,areaThreshold)
    %% calculate background and select fishes that towards different directions
    
    pos = find(strFilePath == '.');
    len = length(pos);
    seqName = strFilePath(1:(length(strFilePath)-4));
    fileName = strcat(seqName,'/',seqName,'_data.mat');
    
    if ~exist('imgSelectedFishes','var')
        if ~exist(fileName,'file')
            [imgSelectedFishes,nMaxHeight,nMaxWidth]=VideoOperate(strFilePath,background,grayThreshold,areaThreshold);
%             save imgSelectedFishes.mat imgSelectedFishes nMaxHeight nMaxWidth;
            save(fileName,'imgSelectedFishes','nMaxHeight','nMaxWidth');
        else
            load(fileName);
        end
    end
%     if ~exist('imgSelectedFishes','var')
%         if ~exist('imgSelectedFishes.mat','file')
%             [imgSelectedFishes,nMaxHeight,nMaxWidth]=VideoOperate(strFilePath);
%             save imgSelectedFishes.mat imgSelectedFishes nMaxHeight nMaxWidth;
%         else
%             load('imgSelectedFishes.mat');
%         end
%     end
    clear strFilePath;
    %% expand the pictures than contains original fishes image to square pictures
    % ����ͳһ�ü������������ͼƬ�Ĵ�С��ʹ��չ���ͼƬ��СΪnMaxHeight��nMaxWidth,����֮ǰ��ͼƬ����չ��ͼ������м�

%     nMaxHeightAndWidth = max(nMaxHeight,nMaxWidth);
    nMaxHeightAndWidth = 200;
    % fishPadded = cell(size(imgSelectedFishes));

    for i = 1:size(imgSelectedFishes,1)
        for j = 1:size(imgSelectedFishes,2)
            if ~isempty(imgSelectedFishes{i,j}.data)
                img = imgSelectedFishes{i,j}.data.imageCroped;
                [nHeight,nWidth,~] = size(img);
                img = img(nHeight,ceil(nWidth/2):end);
                img = scale(img,50,50);
                [nHeight,nWidth,~] = size(img);
                imgSelectedFishes{i,j}.data.imageCroped = padarray(img,[ceil((50 - nHeight)/2) ceil((50 - nWidth)/2)], 255);
%                 [nHeight, nWidth,~]= size(imgSelectedFishes{i,j}.data.imageCroped);
%                 j
                
%                 imgSelectedFishes{i,j}.data.imageCroped = padarray(imgSelectedFishes{i,j}.data.imageCroped,[ceil((nMaxHeightAndWidth - nHeight)/2) ceil((nMaxHeightAndWidth - nWidth)/2)], 255);
                
%                 [nHeight, nWidth,~] = size(imgSelectedFishes{i,j}.data.imageCroped);
%                 imgSelectedFishes{i,j}.data.imageCroped = padarray(img,[ceil((100 - nHeight)/2) ceil((100 - nWidth)/2)], 255);
                % ��������һ�仰�������⣬�����nMaxHeight - nHeight��ֵ����ż������߽���չ�����Ľ����
                % ��Ŀ��ֵ�ĸ߶ȶ���һ�У�����������Ѷ��������ɾ��
                [nHeight, nWidth,~]= size(imgSelectedFishes{i,j}.data.imageCroped);
                if(nHeight~= 100)
                    imgSelectedFishes{i,j}.data.imageCroped(nHeight,:,:) = [];
                end
                if(nWidth ~= 100)
                    imgSelectedFishes{i,j}.data.imageCroped(:,nWidth,:) = [];
                end
            end
        end
    end

    clear nHeight nWidth nMaxHeightAndWidth i j k;
    % clc;
    %%������HOG����feature
    if ~exist('feature2','var')
        feature2 = cell(size(imgSelectedFishes));

        for i = 1:size(imgSelectedFishes,1)
            for j = 1:size(imgSelectedFishes,2)
                if ~isempty(imgSelectedFishes{i,j}.data)
%                     [fmapc,fmapb] = HOGmap(imgSelectedFishes{i,j}.data.imageCroped,9);      %����HOG����
                    feature2{i,j} = HOG_Feature(imgSelectedFishes{i,j}.data.imageCroped,9);           %����HOG����
                end
            end
        end
    end
    
    [nRow,nCol] = size(feature2);%feature2��֡��,����
    nnull = ~cellfun('isempty',feature2);
    if nnull == 0
        return
    end
    row_nnull = find(nnull);
    row_nnull = mod(row_nnull(1,:),size(imgSelectedFishes,1));
    feature = zeros(nRow*nCol,size(feature2{row_nnull,1},2));
%     feature = zeros(nRow*nCol,size(feature2{1,1},2));
   % ȥ��ȫΪ�� ������
    for m = 1:nCol
        for k = 1:nRow
            % ����ͬһ�е�Ԫ��
            if ~isempty(feature2{k,m})
                feature((m-1)*nRow+k,:) = feature2{k,m};
            end
        end
    end
%     subMat(all(subMat == nBackgroundValue,2),:) = [];
    feature(all(feature == 0,2),:) = [];
end
