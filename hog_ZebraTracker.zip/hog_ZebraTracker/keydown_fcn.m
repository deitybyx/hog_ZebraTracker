function keydown_fcn(hObject,eventdata,handles,hFigure)
    addpath('function');
    global gStateControl;
    if all(eventdata.EventName == 'Hit')
        gStateControl.button = eventdata.Button;
        gStateControl.currentMousePosition = eventdata.IntersectionPoint(1:2);
        if gStateControl.button == 3 && (gStateControl.correctionMode == 1 || gStateControl.correctionMode == 2)
            hold on;
            if gStateControl.correctionIndex == 1
                if isempty(gStateControl.correctionMatch)
                    gStateControl.correctionMatchLabel = zeros(2,1);
                    gStateControl.correctionMatchLabel(1,1) = str2double(eventdata.Source.String(3:end));
                    gStateControl.correctionMatch = zeros(4,1);
                    gStateControl.correctionMatch([1,3],end) = gStateControl.currentMousePosition;
                else
                    gStateControl.correctionMatchLabel(1,end+1) = str2double(eventdata.Source.String(3:end));
                    gStateControl.correctionMatch([1,3],end+1) = gStateControl.currentMousePosition;
                end
                plot(gStateControl.correctionMatch([1,2],1:end-1),gStateControl.correctionMatch([3,4],1:end-1),'LineWidth',4);
                plot(gStateControl.correctionMatch(1,end),gStateControl.correctionMatch(3,end),'.','MarkerSize',30,'MarkerEdgeColor',[1 1 1]);
                gStateControl.correctionIndex = 2;
            else 
                gStateControl.correctionMatchLabel(2,end) = str2double(eventdata.Source.String(3:end));
                gStateControl.correctionMatch([2,4],end) = gStateControl.currentMousePosition;
                plot(gStateControl.correctionMatch([1,2],:),gStateControl.correctionMatch([3,4],:),'.','MarkerSize',30,'MarkerEdgeColor',[1 1 1]);
                plot(gStateControl.correctionMatch([1,2],:),gStateControl.correctionMatch([3,4],:),'LineWidth',4);
                gStateControl.correctionIndex = 1;
            end

        end
    end
end