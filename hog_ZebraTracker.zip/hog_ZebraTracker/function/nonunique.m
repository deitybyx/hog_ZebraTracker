% find repeated numbers in x
function n = nonunique(x)

ux = unique(x);
if length(ux)==1 && length(x)>1
    n = ux;
    return;
end
f = hist(x,ux);
n = ux(f>1);