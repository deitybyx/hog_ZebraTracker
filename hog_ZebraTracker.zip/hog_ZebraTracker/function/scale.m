%% 
% @arguments
%   img             gray-image is preferred
%   row_scale       �з���ķŴ���
%   col_scale       �з���ķŴ���
function result = scale(img,row_des,col_des)

% m=1;              %�Ŵ����С�ĸ߶�
% n=2;              %�Ŵ����С�Ŀ���
% img=imread('lena.jpg');
% img=rgb2gray(img);
if length(size(img)) >2
    img = rgb2gray(img);
end
% imshow(img);
[row col]=size(img);

if row > col
    col_des = floor(row_des/row*col);
else
    row_des = floor(col_des/col * row);
end




imgn=zeros(row_des,col_des);
rot=[row_des/row 0 0;0 col_des/col 0;0 0 1];                                   %�任����

for i=1:row_des
    for j=1:col_des
        pix=[i j 1]/rot;   
        
        float_Y=pix(1)-floor(pix(1)); 
        float_X=pix(2)-floor(pix(2));
       %�߽紦��
        if pix(1) < 1
            pix(1) = 1;
        end
        
        if pix(1) > row
            pix(1) = row;
        end
        
        if pix(2) < 1
            pix(2) =1;
        end
        
        if pix(2) > col
            pix(2) =col;
        end
        
        pix_up_left=[floor(pix(1)) floor(pix(2))];%�ĸ����ڵĵ�
        pix_up_right=[floor(pix(1)) ceil(pix(2))];
        pix_down_left=[ceil(pix(1)) floor(pix(2))];
        pix_down_right=[ceil(pix(1)) ceil(pix(2))];     
    
        value_up_left=(1-float_X)*(1-float_Y);%�����ٽ��ĸ����Ȩ��
        value_up_right=float_X*(1-float_Y);
        value_down_left=(1-float_X)*float_Y;
        value_down_right=float_X*float_Y;
%��Ȩ�ؽ���˫���Բ�ֵ
        imgn(i,j)=value_up_left*img(pix_up_left(1),pix_up_left(2))+ ...
                  value_up_right*img(pix_up_right(1),pix_up_right(2))+ ...
                  value_down_left*img(pix_down_left(1),pix_down_left(2))+ ...
                  value_down_right*img(pix_down_right(1),pix_down_right(2));        
    end
end

% figure(2),imshow(uint8(imgn)) ;
result = uint8(imgn);
end