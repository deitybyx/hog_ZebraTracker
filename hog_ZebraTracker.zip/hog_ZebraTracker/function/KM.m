function [PredictLeft,PredictRight] = KM(distance)
    [nRow,nCol] = size(distance);
    fTransferred = 0;
    if nCol<nRow
        distance = distance';
        fTransferred = 1;
    end
    
    [nRow,nCol] = size(distance);
    dis = distance;
%     if nRow <= nCol
        PredictLeft = zeros(1,nRow);
        [dis,index] = sort(dis,2);
        
        current = ones(nRow,1);
        for i = 1:nRow
            % �����ӵ�i�е���Сֵ
            PredictLeft(i) = index(i,current(i));
            
            % ���ж��Ƿ�����Ҫ���ģ������Ҫ������ѭ���ж�
            uniq = unique(PredictLeft(1:i));    % ȡǰi֡�����ж�
            while length(uniq)<i
                % Ѱ������һ���ظ���
                conflictValue = 1;
                for j = 1:length(uniq)
                    if sum(PredictLeft(1:i) == uniq(j)) > 1 % ���ظ���
                        conflictValue = uniq(j);
                        break;
                    end
                end
                % ��������
                deltaX = zeros(1,nRow);
                for j = 1:nRow
                    if current(j) < nCol-1          % *********************
                        deltaX(j) = dis(j,current(j)+1) - dis(j,current(j));
                    end
                end
                deltaX(PredictLeft ~= conflictValue) = inf;
                [~,ind] = min(deltaX);
                ind = ind(length(ind));
                
                current(ind) = current(ind) + 1;
                % Change that need changing
                PredictLeft(ind) = index(ind,current(ind));
                uniq = unique(PredictLeft(1:i));
            end
        end
%     end
    %% Calculate another prediction label
    % Method 01
%     if fTransferred == 1
%         PredictRight = zeros(1,nCol);
%         PredictRight(PredictLeft) = 1:nRow;
%         indexZeros = PredictRight == 0;
%         [~,indexMin] = min(distance(:,indexZeros),[],1);
%         PredictRight(indexZeros) = indexMin;
%     else
%         PredictRight = PredictLeft;
%         PredictLeft = zeros(1,nCol);
%         PredictLeft(PredictRight) = 1:nRow;
%         indexZeros = PredictLeft == 0;
%         [~,indexMin] = min(distance(:,indexZeros),[],1);
%         PredictLeft(indexZeros) = indexMin;
%     end
    % Method 02
    PredictRight = zeros(1,nCol);
    PredictRight(PredictLeft) = 1:nRow;
    indexZeros = PredictRight == 0;
    [~,indexMin] = min(distance(:,indexZeros),[],1);
    PredictRight(indexZeros) = indexMin;
    if fTransferred == 1
        [PredictLeft,PredictRight] = deal(PredictRight,PredictLeft);
    end
end
%     if nRow == nCol     % ���󼯺��Ҽ�����Ŀ���ʱ
%         PredictLeft = zeros(1,nCol);
% 
%         [dis,index] = sort(dis,2);
%         current = ones(nRow,1);
%         for i = 1:nRow
%             % �����ӵ�i�е���Сֵ
%             PredictLeft(i) = index(i,current(i));
%             
%             % ���ж��Ƿ�����Ҫ���ģ��������Ҫ����ѭ���ж�
%             uniq = unique(PredictLeft(1:i));
%             while length(uniq) < i% sum(PredictLeft == index(i,current(i))) > 1
%                 conflictValue = 1;
%                 for j = 1:size(uniq,2)
%                     if sum(PredictLeft(1:i) == uniq(j)) > 1
%                         conflictValue = uniq(j);
%                         break;
%                     end
%                 end
% %                 conflict = PredictLeft == index(i,current(i));
%                 deltaX = zeros(1,nRow);
%                 for j = 1:nRow
%                     disp(current(j));
%                     if current(j) < nRow
%                         deltaX(j) = dis(j,current(j)+1) - dis(j,current(j));
%                     else
%                         deltaX(j) = inf;
%                     end
%                 end
%                 
%                 deltaX(PredictLeft ~= conflictValue) = inf;
%                 [~,ind] = min(deltaX);
%                 ind = ind(length(ind));
%                                 
%                 current(ind) = current(ind) + 1;
%                 % �ı���Ҫ���ĵ�
%                 % 
%                 PredictLeft(ind) = index(ind,current(ind));
%                 uniq = unique(PredictLeft(1:i));
%             end
%                 disp(PredictLeft);
%         end
%         PredictRight = zeros(1,nRow);
%         PredictRight(:,PredictLeft) = 1:nRow;
%         disp(index);
%     end
